using System.Collections.Generic;
using System.Linq;
using Mark.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Mark.Pages
{
    public class StudentRecordModel : PageModel
    {
        public StudentRecordModel(DBContext studentFormDBContext) 
        {
            userDBContext = studentFormDBContext;
        }
        private readonly DBContext userDBContext;


        [BindProperty]
        public registrationForm registeruser { get; set; }

        public List<registrationForm> register = new List<registrationForm>();
        public void OnGet()
        {
            //cant connect due to sql problem
            //register = userDBContext.register.ToList();
        }
        public ActionResult OnPost() 
        {
            if(!ModelState.IsValid) 
            {
                //cant connect due to sql problem
                //register = userDBContext.register.ToList();
                return Page();

            }
            userDBContext.register.Add(registeruser);
            userDBContext.SaveChanges();
            return Redirect("/Index");
        }
    }
}
