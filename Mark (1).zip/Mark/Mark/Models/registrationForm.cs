﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Mark.Models
{
    public class registrationForm
    {
        
        [RegularExpression(@"([1-9][0-9]*)", ErrorMessage = "Invalid must a number"), Required, StringLength(8)]
        public int ID { get; set; }
        [RegularExpression(@"^[\w'\-,.][^0-9_!¡?÷?¿/\\+=@#$%ˆ&*(){}|~<>;:[\]]{2,}$", ErrorMessage = "Lastname Invalid"), Required, StringLength(50)]
        public string Firstname { get; set; }
        [RegularExpression(@"^[\w'\-,.][^0-9_!¡?÷?¿/\\+=@#$%ˆ&*(){}|~<>;:[\]]{2,}$", ErrorMessage = "Middlename Invalid"), Required, StringLength(50)]
        public string Middlename { get; set; }
        [RegularExpression(@"^[\w'\-,.][^0-9_!¡?÷?¿/\\+=@#$%ˆ&*(){}|~<>;:[\]]{2,}$", ErrorMessage = "Lastname Invalid"), Required, StringLength(50)]
        public string Lastname { get; set; }
        [RegularExpression(@"^[\w'\-,.][^0-9_!¡?÷?¿/\\+=@#$%ˆ&*(){}|~<>;:[\]]{2,}$", ErrorMessage = "Course Invalid"), Required, StringLength(50)]
        public string Course { get; set; }
        [RegularExpression(@"^(0?[1-5]|[1-5][0-5]|[1][1-5][1-5]|1)$", ErrorMessage = "invalid must a number 1-5"), Required]
        public string Year { get; set; }
        [RegularExpression(@"^(0?[1-9]|[1-9][0-9]|[1][1-9][1-9])$", ErrorMessage = "Invalid must be a number"), Required]
        public string Contact { get; set; }
    }
}
